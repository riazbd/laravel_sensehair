﻿/*
 Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("codesnippet","sr",{button:"Налепи делић кода",codeContents:"Садржај кода",emptySnippetError:"Делић кода не може бити празан",language:"Језик",title:"Делић кода",pathName:"Делић кода"});