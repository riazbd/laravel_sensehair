/*
*
* Backpack Crud / Show
*
*/

jQuery(function($){

    'use strict';
});
